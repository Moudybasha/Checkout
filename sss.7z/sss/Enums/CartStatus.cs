﻿namespace CheckoutCart.Services.Enums
{
    internal enum CartStatus
    {
        InProgress,
        Finialized
    }
}